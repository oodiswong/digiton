var wiz_count = 1;

$(document).ready(function() {
    $("#pg_title").text( 'Maintenane Form' );
    //$('.selectpicker').selectpicker();
    
});

$('#btn_sec4_complete').click(function(){
    Swal.fire({
        title: 'Do you want to review all information?',
        confirmButtonClass: 'btn btn-info btn-w1 mr-2',
        cancelButtonClass: 'btn btn-default btn-w1 ml-2',
        showCancelButton: true,
        buttonsStyling: false
    }).then((result) => {
        if (result.value) {
            if( !$('#sec1_collapse').hasClass("show") ){
                $('#sec1_title').trigger( "click" );
            }
            if( !$('#sec2_collapse').hasClass("show") ){
                $('#sec2_title').trigger( "click" );
            }
            if( !$('#sec3_collapse').hasClass("show") ){
                $('#sec3_title').trigger( "click" );
            }
        }else{
            $('#sec4_title').trigger( "click" );
        }
    })
});

$('input[type=radio][name=radio_cmp]').change(function() {
    if (this.value == '1') {
        $('#r_cmp2_sel').attr("disabled","disabled");
    }
    else if (this.value == '2') {
        $('#r_cmp2_sel').removeAttr("disabled");
    }
});

function continueExecution()
{
   //finish doing things after the pause
}

$('.btn_wiz').click(function(){
    var res = this.id.split(";");
    $("div.tab-pane.show.active").removeClass("show active");
 
    var ShowPage = document.getElementById(res[1]);
    ShowPage.style.display = "block";
    ShowPage.classList.remove("hidden");
    var HidePage = document.getElementById(res[0]);
    HidePage.style.display = "none";

    if (this.value != "next") {
        $("div.tab-pane.show.active").removeClass("show active");
        //$('#sec' + ($(this).val()) + '_body').removeClass("hidden");
        $('#sec' + ($(this).val()) + '_wizard').removeClass("hidden");
        $('#sec' + ($(this).val()) + '_title').trigger( "click" );
        $($(this).attr("next")).addClass("show active");
    }
    
    /*
    if (this.value == '2') {
        $("div.tab-pane.show.active").removeClass("show active");

        //var NextBody = document.getElementById("sec2_body");
        //NextBody.classList.remove("hidden");
        var NextWiz = document.getElementById("sec2_wizard");
        NextWiz.classList.remove("hidden");
        var event = new MouseEvent('click', {
            view: window,
            bubbles: true,
            cancelable: true
          });
        var NextSect = document.getElementById("sec2_title");
        NextSect.dispatchEvent(event);
        $($(this).attr("next")).addClass("show active");
    }
    */
    /*
    $("div.tab-pane.show.active").removeClass("show active");
    if (this.value == 'next') {
        $($(this).attr("next")).addClass("show active");
    }else{
        $('#sec' + ($(this).val()) + '_body').removeClass("hidden");
        $('#sec' + ($(this).val()) + '_wizard').addClass("hidden");
        $('#sec' + ($(this).val()) + '_title').trigger( "click" );
        //$('#sec' + $(this).val()  + '_title_disable').hide();
        //$('#sec' + $(this).val()  + '_title').removeClass("hidden");
        //$('#sec' + $(this).val()  + '_title').trigger( "click" );
        $($(this).attr("next")).addClass("show active");
    } 
    */
});

$('input[type="checkbox"][name=auth1]').on('change', function() {
    $('input[type="checkbox"][name=auth1]').not(this).prop('checked', false);
 });

 $('input[type="checkbox"][name=ctgy1]').on('change', function() {
    $('input[type="checkbox"][name=ctgy1]').not(this).prop('checked', false);
 });