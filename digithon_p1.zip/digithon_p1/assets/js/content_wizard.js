$(document).ready(function() {
    $("#_wizard1").load( $('#sel_req').val() + ".html" );
});

$('#btn_discard').click(function(){
    location.reload();
});

$('#btn_draft').click(function(){
    location.reload();
});