$(document).ready(function() {
    // $('.selectpicker').selectpicker();

    $('#requestTable').DataTable({
        "paging":   false,
        "info":     false,
        "lengthMenu": [[-1], ["All"]],
        "language": {
            "emptyTable": " ",
            "zeroRecords": " ",
        }
    });

    $('#txt_requestCount').text( $('#pendingTable').DataTable().data().count() );
});

$('#btn_request').click(function(){
    Swal.fire({
        title: 'Select the Request Type',
        html: '<div class="col-md-9 ml-auto mr-auto"><select id="sel_req" class="form-control text-center">' 
                + '<optgroup label="Form">'
                + '<option value="mt_form1">Maintenance Form</option>'
                + '</optgroup>'
                + '<optgroup label="">'
                + '</optgroup>'
                + '</select></div>',
        confirmButtonClass: 'btn btn-success btn-w1 ml-2',
        cancelButtonClass: 'btn btn-danger btn-w1 mr-2',
        showCancelButton: true,
        reverseButtons: true,
        buttonsStyling: false,
        customClass: 'swal-wide'
    }).then((result) => {
        if (result.value) {
            sessionStorage.setItem("req_option", $('#sel_req').val());
            $("#_content").empty();
            $("#_content").load( "wizard.html" );
        }
    })
});

$('#btn_md').click(function(){
    $("#_content").empty();
    $("#_content").load( $('#sel_req').val() + ".html" );
});