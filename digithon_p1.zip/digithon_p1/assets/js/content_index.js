$(function () {
    $('#_year').html(new Date().getFullYear());
    $("#_content").load( $('#menu_sidebar > .active').attr('id') + ".html" ); 

})

$('#menu_sidebar').on( 'click', 'li', function () {
    $('.nav li').removeClass('active');
    $(this).addClass('active');

    $("#_content").empty();
    $("#_content").load( $(this).attr('id') + ".html" ); 
    $("#pg_title").text( $(this).attr('desc') );
})